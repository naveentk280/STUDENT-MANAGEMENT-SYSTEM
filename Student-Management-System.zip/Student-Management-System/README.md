# Student Management System

A Flask + SQLAlchemy student management system with MVC structure.

## Project Structure

- app/
  - controllers/
  - models/
  - routes/
  - templates/
    - auth/
    - students/
  - static/
    - css/
    - js/
  - utils/
- instance/
- requirements.txt
- run.py
