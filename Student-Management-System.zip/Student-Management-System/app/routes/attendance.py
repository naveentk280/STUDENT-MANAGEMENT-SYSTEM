from flask import Blueprint, flash, redirect, render_template, request, session, url_for

from app import db
from app.controllers.student_controller import StudentController
from app.models.student import Student

attendance_bp = Blueprint('attendance', __name__)


@attendance_bp.before_request
def require_login():
    """Protect attendance routes so only authenticated users can access them."""
    if request.endpoint not in {'static'} and 'user_id' not in session:
        return redirect(url_for('auth.login'))


@attendance_bp.route('/attendance', methods=['GET', 'POST'])
def attendance_page():
    """Display the attendance page and save attendance entries."""
    students = StudentController.list_students()

    if request.method == 'POST':
        present_ids = request.form.getlist('present_ids')
        present_set = set(int(id_) for id_ in present_ids if id_.isdigit())

        for student in students:
            student.present_today = student.id in present_set

        db.session.commit()
        flash('Attendance saved successfully.', 'success')
        return redirect(url_for('attendance.attendance_page'))

    return render_template('students/attendance.html', students=students)
