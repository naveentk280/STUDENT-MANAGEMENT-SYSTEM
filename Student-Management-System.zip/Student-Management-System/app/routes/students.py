from flask import Blueprint, flash, redirect, render_template, request, session, url_for

from app import db
from app.controllers.student_controller import StudentController
from app.models.student import Student

students_bp = Blueprint('students', __name__)


@students_bp.before_request
def require_login():
    """Protect student routes so only authenticated users can access them."""
    if request.endpoint not in {'static'} and 'user_id' not in session:
        return redirect(url_for('auth.login'))


@students_bp.route('/students')
def list_students():
    """Display all students in the database."""
    search = request.args.get('q', '').strip()
    students = StudentController.list_students(search)
    return render_template('students/list.html', students=students, search=search)


@students_bp.route('/students/new', methods=['GET', 'POST'])
def new_student():
    """Create a new student record."""
    if request.method == 'POST':
        data = {
            'first_name': request.form.get('first_name', '').strip(),
            'last_name': request.form.get('last_name', '').strip(),
            'email': request.form.get('email', '').strip(),
            'phone': request.form.get('phone', '').strip(),
            'course': request.form.get('course', '').strip(),
        }

        if not all([data['first_name'], data['last_name'], data['email']]):
            flash('First name, last name, and email are required.', 'danger')
            return render_template('students/new.html')

        student = Student(**data)
        db.session.add(student)
        db.session.commit()
        flash('Student registered successfully.', 'success')
        return redirect(url_for('students.list_students'))

    return render_template('students/new.html')


@students_bp.route('/students/<int:student_id>/edit', methods=['GET', 'POST'])
def edit_student(student_id):
    """Edit an existing student record."""
    student = StudentController.get_student(student_id)

    if request.method == 'POST':
        data = {
            'first_name': request.form.get('first_name', '').strip(),
            'last_name': request.form.get('last_name', '').strip(),
            'email': request.form.get('email', '').strip(),
            'phone': request.form.get('phone', '').strip(),
            'course': request.form.get('course', '').strip(),
        }

        if not all([data['first_name'], data['last_name'], data['email']]):
            flash('First name, last name, and email are required.', 'danger')
            return render_template('students/edit.html', student=student)

        StudentController.update_student(student_id, data)
        flash('Student updated successfully.', 'success')
        return redirect(url_for('students.list_students'))

    return render_template('students/edit.html', student=student)


@students_bp.route('/students/<int:student_id>/delete', methods=['POST'])
def delete_student(student_id):
    """Delete a student record."""
    StudentController.delete_student(student_id)
    flash('Student deleted successfully.', 'success')
    return redirect(url_for('students.list_students'))
