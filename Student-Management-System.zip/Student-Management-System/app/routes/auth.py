from flask import Blueprint, flash, redirect, render_template, request, session, url_for

from app.controllers.auth_controller import AuthController

# Create a blueprint for authentication-related routes.
auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """Handle user login and start a session."""
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()

        user = AuthController.authenticate(username, password)
        if user:
            session['user_id'] = user.id
            session['username'] = user.username
            flash('Login successful.', 'success')
            return redirect(url_for('main.index'))

        flash('Invalid username or password.', 'danger')

    return render_template('auth/login.html')


@auth_bp.route('/logout')
def logout():
    """End the current user session."""
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('auth.login'))
