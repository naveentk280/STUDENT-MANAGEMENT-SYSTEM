from app import db


class Student(db.Model):
    """Student record model."""
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(80), nullable=False)
    last_name = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(20), nullable=True)
    course = db.Column(db.String(100), nullable=True)
    present_today = db.Column(db.Boolean, default=False, nullable=False)

    def __repr__(self):
        return f'<Student {self.first_name} {self.last_name}>'
