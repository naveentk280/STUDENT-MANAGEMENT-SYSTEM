from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from pathlib import Path

# Initialize SQLAlchemy instance
db = SQLAlchemy()


def create_app():
    app = Flask(__name__, instance_relative_config=True)

    # Basic app configuration
    app.config['SECRET_KEY'] = 'dev-secret-key'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + str(Path(app.instance_path) / 'students.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    db.init_app(app)

    # Import models so SQLAlchemy can create the tables.
    from app.models import student, user  # noqa: F401

    # Register blueprints for the app
    from app.routes.attendance import attendance_bp
    from app.routes.auth import auth_bp
    from app.routes.main import main_bp
    from app.routes.students import students_bp
    app.register_blueprint(main_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(students_bp)
    app.register_blueprint(attendance_bp)

    with app.app_context():
        db.create_all()
        from app.controllers.auth_controller import AuthController
        if not AuthController.authenticate('admin', 'admin123'):
            AuthController.create_admin('admin', 'admin@example.com', 'admin123')

    return app
