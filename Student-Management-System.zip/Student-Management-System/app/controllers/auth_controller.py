"""Authentication-related controller logic."""

from app import db
from app.models.user import User


class AuthController:
    """Handle login and authentication operations."""

    @staticmethod
    def authenticate(username, password):
        """Validate a username/password combination."""
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            return user
        return None

    @staticmethod
    def create_admin(username, email, password):
        """Create a new admin account with a hashed password."""
        if User.query.filter((User.username == username) | (User.email == email)).first():
            return None

        user = User(username=username, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        return user
