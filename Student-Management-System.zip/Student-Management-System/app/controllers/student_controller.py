"""Student management controller logic."""

from sqlalchemy import or_

from app import db
from app.models.student import Student


class StudentController:
    """Handle student-related business logic."""

    @staticmethod
    def list_students(search=None):
        """Return students, optionally filtered by a search term."""
        query = Student.query
        if search:
            term = f'%{search}%'
            query = query.filter(
                or_(
                    Student.first_name.like(term),
                    Student.last_name.like(term),
                    Student.email.like(term),
                    Student.course.like(term),
                )
            )
        return query.order_by(Student.id.asc()).all()

    @staticmethod
    def get_student(student_id):
        """Fetch a single student by ID."""
        return Student.query.get_or_404(student_id)

    @staticmethod
    def update_student(student_id, data):
        """Update an existing student record."""
        student = Student.query.get_or_404(student_id)
        for key, value in data.items():
            setattr(student, key, value)
        db.session.commit()
        return student

    @staticmethod
    def delete_student(student_id):
        """Delete a student record by ID."""
        student = Student.query.get_or_404(student_id)
        db.session.delete(student)
        db.session.commit()
        return True
