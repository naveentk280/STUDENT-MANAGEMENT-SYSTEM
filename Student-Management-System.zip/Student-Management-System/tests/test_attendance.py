import unittest

from app import create_app, db
from app.models.student import Student


class AttendanceRouteTests(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.app.config['TESTING'] = True
        self.app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'

        self.client = self.app.test_client()

        with self.app.app_context():
            db.drop_all()
            db.create_all()

            student = Student(first_name='Alice', last_name='Brown', email='alice@example.com', course='Computer Science')
            db.session.add(student)
            db.session.commit()

    def test_attendance_page_loads_for_authenticated_user(self):
        with self.client.session_transaction() as session:
            session['user_id'] = 1
            session['username'] = 'admin'

        response = self.client.get('/attendance')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Attendance', response.data)

    def test_attendance_can_be_marked(self):
        with self.client.session_transaction() as session:
            session['user_id'] = 1
            session['username'] = 'admin'

        with self.app.app_context():
            student = Student.query.first()
            response = self.client.post('/attendance', data={'present_ids': [str(student.id)]}, follow_redirects=True)

        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Attendance saved successfully.', response.data)


if __name__ == '__main__':
    unittest.main()
